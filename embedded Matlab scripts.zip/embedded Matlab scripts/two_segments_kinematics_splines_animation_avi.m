%This is a Matlab script embedded in the LabView auto foil kinematics vi.

%For each frame in the foil video, plots the spline fit to the detected 
%foil on a blank field and saves each plot as a frame in an avi.
%This version is for when there are 2 foil segments & a gap between.


%Inputs:
%preSPLINES - an array of column vectors.  Column 1 is x-data for the
    %spline of frame 1, Column 2 is the corresponding y-data, Column 3 is
    %the x-data for the spline in frame 2, etc.  Data are in mm.
%Step - increment between frames that will be plotted and saved (ex:
    %Step=20 means plot spline for frame 1, 21, 41, etc).  Reduces file
    %size and increases playback speed of saved AVI
%Scale - (1024)*(DaVis pixel scale factor - the mm/pixel conversion)
%F - the file path where the avi animation will be saved
%gapx - x-coordinate (in pixels) inside the gap between segments


%Output:
%Saves an avi animation of the foil's movements

j=0;        %initialize index for data structure where plots are stored
imagenum=1;     %initialize index for current frame number
c1=1;           %initialize index for the x-data column
c2=2;           %initialize index for the y-data column
SPLINES=preSPLINES(2:end,:);        %eliminate the first row of preSPLINES (contains labels)
clear M         %clear the data structure of old animations still in memory


while imagenum<=size(SPLINES,2)/2
    
    p=SPLINES(:,c1);        %get the x data for the spline
    q=SPLINES(:,c2);        %get the y data for the spline
    
    ind = 1;
    
    while ind < size(q,1)+1
        if q(ind) ~= 0
            q(ind)= Scale - q(ind);
        end
        ind = ind + 1;
    end
    
    
    %Storage for the front segment
    pfront = [];
    qfront = [];
    n = 1;
    
    %Find index of gapx value
    [tf, num]=ismember(round(gapx),round(p));

    %Extract just the front portion from the full data set
    while n<num
        pfront = [pfront, p(n)];
        qfront = [qfront, q(n)];
        n=n+1;
    end

    %Storage for the back segment
    pback = [];
    qback = [];

    %Extract just the back portion from the whole data set
    while n < size(p,1)+1
        pback = [pback, p(n)];
        qback = [qback, q(n)];
        n=n+1;
    end

    %Figure out where the y-coordinate is not zero (the foil) for the front
    %part
    totcol = size(pfront,2);
    i=1;
    while i<=totcol
        datanotzero=(qfront(1,i)~=0);
        if datanotzero==0
            pfront(1,i)=0;
        end
        i=i+1;
    end

    %Figure out where the y-coordinate is not zero (the foil) for the back
    %part
    totcol = size(pback,2);
    i=1;
    while i<=totcol
        datanotzero=(qback(1,i)~=0);
        if datanotzero==0
            pback(1,i)=0;
        end
        i=i+1;
    end

    %Set all the x-coordinates to zero where the corresponding y-coordinate
    %is zero.  Then keep only the coordinates with values (on the foil).
    pfront=pfront(1,:);
    colnotzero=(pfront~=0);
    pfront=pfront(colnotzero);

    qfront=qfront(1,:);
    colnotzero=(qfront~=0);
    qfront=qfront(colnotzero);

    pback=pback(1,:);
    colnotzero=(pback~=0);
    pback=pback(colnotzero);

    qback=qback(1,:);
    colnotzero=(qback~=0);
    qback=qback(colnotzero);

    %Plot the foil segments in the same color on the same plot
    figure(1)
    plot(pfront,qfront,'Color',[0,0.4470,0.7410],'LineWidth',2)
    hold on
    plot(pback,qback,'Color',[0,0.4470,0.7410],'LineWidth',2)
    axis([0 Scale 0 Scale])
    hold off
    
    
    
    %Save the current spline pair to the animation
    j=j+1;
    M(j)=getframe(gcf);
    
    %go on to the next frame
    c1=c1+2*Step;
    c2=c2+2*Step;

    imagenum=imagenum+Step;

end
    
movie2avi(M,F)
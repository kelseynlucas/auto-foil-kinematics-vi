%This is a Matlab script embedded in the LabView auto foil kinematics vi.

%For each frame in the foil video, plots the spline fit to the detected 
%foil on a blank field and saves each plot as a frame in an avi.


%Inputs:
%preSPLINES - an array of column vectors.  Column 1 is x-data for the
    %spline of frame 1, Column 2 is the corresponding y-data, Column 3 is
    %the x-data for the spline in frame 2, etc.  Data are in mm.
%Step - increment between frames that will be plotted and saved (ex:
    %Step=20 means plot spline for frame 1, 21, 41, etc).  Reduces file
    %size and increases playback speed of saved AVI
%Scale - (1024)*(DaVis pixel scale factor - the mm/pixel conversion)
%F - the file path where the avi animation will be saved


%Output:
%Saves an avi animation of the foil's movements


j=0;        %initialize index for data structure where plots are stored
imagenum=1;     %initialize index for current frame number
c1=1;           %initialize index for the x-data column
c2=2;           %initialize index for the y-data column
SPLINES=preSPLINES(2:end,:);        %eliminate the first row of preSPLINES (contains labels)
clear M         %clear the data structure of old animations still in memory


while imagenum<=size(SPLINES,2)/2       %keep going until the current image number exceeds the number of frames in the original foil video
    
    p=SPLINES(:,c1);        %get the x data for the spline
    q=SPLINES(:,c2);        %get the y data for the spline
    q=Scale-q;

    figure(1)
    plot(p,q,'LineWidth',2)     %plot the spline
    axis([0 Scale 0 Scale])     %set the axes to match the original foil video's dimensions in mm
    
    j=j+1;      %set index
    M(j)=getframe(gcf);         %store the plot
    
    c1=c1+2*Step;           %set index to look for the x-data of the next desired frame's spline
    c2=c2+2*Step;           %set index to look for the y-data of the next desired frame's spline

    imagenum=imagenum+Step;         %increment the current image number

end
    
movie2avi(M,F)          %save the frames in the data structure to file path F.
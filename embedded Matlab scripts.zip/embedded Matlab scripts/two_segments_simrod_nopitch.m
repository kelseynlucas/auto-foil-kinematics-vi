%This is a Matlab script embedded in the LabView auto foil kinematics vi.

%Finds two segments of the foil and preps data for further processing.
%Simulates the rod without pitch (heave only).


%Inputs:
%A - an array with 2 rows.  Row 1 is the detected x data of the surface in mm.
    %Row 2 contains the detected y data in mm.
%rod - the rod width in mm
%pixfact - the DaVis pixel scale factor (mm/pixel conversion)
%im - the current image/frame number from the original video
%gapx - x-coordinate (in pixels) in the gap


%Output:
%SPL - the spline for the current frame of the foil video
%SNAPS - spline but with gap indicated by (x, 0) points


%Store front portion and back portion of array A
Afront = [];
Aback = [];

%Get the front portion of A (before gapx value)
n=1;
while n<gapx
    Afront(:,n) = A(:,n);
    n = n+1;
    
end

%Get the back portion of A (after gapx value)
back_index = 1;
while n < 1025;
    Aback(:,back_index)=A(:,n);
    n = n+1;
    back_index=back_index+1;
    
end


%Deal with Front portion

%get width of front portion (# pixels horizontally)
totcolf = size(Afront,2);

i=1;        %initialize an index
while i<=totcolf
    datanotzero=(Afront(2,i)~=0);    %make a boolean row vector with dimensions equal to the y data row of A.  0 if the value in A is 0, 1 if the value in A is not zero
    if datanotzero==0
        Afront(:,i)=0;   %if a y-value in Afront is 0, make its x-value zero too
    end
    i=i+1;
end

%Filter out the zeros; break into an x-data matrix and a y-data matrix
D1f=Afront(1,:);
colnotzero=(D1f~=0);
D1f=D1f(colnotzero);

D2f=Afront(2,:);
colnotzero=(D2f~=0);
D2f=D2f(colnotzero);


%Simulate rod 
x1f=D1f(1,1);     %get the x of the detected leading edge of the foil
y1f=mean(D2f(1,1:10));        %get y for the rod (horizontal line - y is constant) - average y value of the first 10 detected points
xf=x1f-rod;       %get the leading edge of the rod - the width of the rod away from the detected foil's leading edge
yf=y1f;           %set y for the rod
xrod=[];        %initialize array to store rod x's
yrod=[];        %initialize array to store rod y's
xnew=0;         %initialize x value to be calculated
g=1;            %initialize index
while xnew+pixfact<x1f           %keep adding points until reach the detected foil
    xnew=xf+g*pixfact;           %get next x point on rod
    xrod=[xrod,xnew];           %store it
    yrod=[yrod,y1f];             %store next y point
    g=g+1;
end
D1f=[xf,xrod,D1f];         %add the rod onto the detected foil
D2f=[yf,yrod,D2f];


%When fitting a spline to all the detected points, there's too many points
%to get a nice, smooth line.  Need to downsample the detected data.

colnum=1;       %initialize index (column number)
zf=[];           %initialize array to store downsampled x's
zzf=[];          %initialize array to store y's corresponding to the downsampled x's
incr=linspace(1,size(D1f,2),20);         %Will take 20 x values, which have these indices
incr=round(incr);       %Make sure indices are integers
spacing=0;      %initialize an index
k=0;            %initialize an index
while colnum<=size(incr,2)      %go through all the indices in incr
    spacing=spacing+1;
    k=incr(1,spacing);
    zf=[zf D1f(1,k)];          %take the x value at k, where k is the next index value listed in incr
    zzf=[zzf D2f(1,k)];        %take the corresponding y value
    colnum=colnum+1;
end

pf=linspace(zf(1,1),zf(1,end),104);        %Get 104 evenly spaced x values between the leading and trailing edges
qf=spline(zf,zzf,pf);                       %Fit a spline to the detected surface, and save it as a list of 104 points with x's as chosen in p
XSPLINEf=[im pf];         %label with image number
XSPLINEf=XSPLINEf';
YSPLINEf=[NaN qf];        %NaN to make y-value vector have same length as x-value vector
YSPLINEf=YSPLINEf';
SPLf=[XSPLINEf YSPLINEf];      %store spline as two column array





%Repeat for back...minus rod part.

totcolb = size(Aback,2);

i=1;        %initialize an index
while i<=totcolb
    datanotzero=(Aback(2,i)~=0);    %make a boolean row vector with dimensions equal to the y data row of A.  0 if the value in A is 0, 1 if the value in A is not zero
    if datanotzero==0
        Aback(:,i)=0;   %if a y-value in Afront is 0, make its x-value zero too
    end
    i=i+1;
end

%Filter out the zeros; break into an x-data matrix and a y-data matrix
D1b=Aback(1,:);
colnotzero=(D1b~=0);
D1b=D1b(colnotzero);

D2b=Aback(2,:);
colnotzero=(D2b~=0);
D2b=D2b(colnotzero);



%When fitting a spline to all the detected points, there's too many points
%to get a nice, smooth line.  Need to downsample the detected data.

colnum=1;       %initialize index (column number)
zb=[];           %initialize array to store downsampled x's
zzb=[];          %initialize array to store y's corresponding to the downsampled x's
incr=linspace(1,size(D1b,2),20);         %Will take 20 x values, which have these indices
incr=round(incr);       %Make sure indices are integers
spacing=0;      %initialize an index
k=0;            %initialize an index
while colnum<=size(incr,2)      %go through all the indices in incr
    spacing=spacing+1;
    k=incr(1,spacing);
    zb=[zb D1b(1,k)];          %take the x value at k, where k is the next index value listed in incr
    zzb=[zzb D2b(1,k)];        %take the corresponding y value
    colnum=colnum+1;
end

pb=linspace(zb(1,1),zb(1,end),100);        %Get 100 evenly spaced x values between the leading and trailing edges
qb=spline(zb,zzb,pb);                       %Fit a spline to the detected surface, and save it as a list of 100 points with x's as chosen in p
XSPLINEb=[pb];         
XSPLINEb=XSPLINEb';
YSPLINEb=[qb];        
YSPLINEb=YSPLINEb';
SPLb=[XSPLINEb YSPLINEb];      %store spline as two column array



SPL=[SPLf;SPLb];                %Final spline for output.  204 points long to be compatible with other code.  Foil only, no points in gap.






%second set of splines for snapshots and amposcill

%Make splines for the front and back, but get one point per pixel instead
%of another number.
pf_snaps = linspace(zf(1,1),zf(1,end),size(D1f,2));
qf_snaps = spline(zf,zzf,pf_snaps);

pb_snaps = linspace(zb(1,1),zb(1,end),size(D1b,2));
qb_snaps = spline(zb,zzb,pb_snaps);


%Format front portion splines
xsnapsf=[pf_snaps];         
xsnapsf=xsnapsf';
ysnapsf=[qf_snaps];        
ysnapsf=ysnapsf';
snapsf = [xsnapsf ysnapsf];

%Format back portion splines
xsnapsb=[pb_snaps];         
xsnapsb=xsnapsb';
ysnapsb=[qb_snaps];        
ysnapsb=ysnapsb';
snapsb = [xsnapsb ysnapsb];

%Get x-coor of front segment's trailing edge, and x-coor of back segment's
%leading edge
TEfx = max(xsnapsf);
LEbx = xsnapsb(1);

%Get all the x-values in the image
allXvals = A(1,:);

%Get the indices of the leading & trailing edge values from above.
[tf, indTEf] = ismember(TEfx, allXvals);
[tf, indLEb] = ismember(LEbx, allXvals);


%Initialize storage for the x-coor in the gap between segments
gap_xcoor = [];


col = indTEf+1;         %will start retrieving x-coor after the trailing edge
n=1;

%For every pixel between the trailing and leading edges, get the
%x-coordinate.
while col < indLEb
    
    gap_xcoor(n) = allXvals(col);
    col = col + 1;
    n = n+1;
    
end


%Set all y's in the gap equal to zero.  Format the x- and y-coor for the
%gap.
gap_ycoor = zeros(size(gap_xcoor,2),1);
gap_xcoor = gap_xcoor';
gap_coor = [gap_xcoor gap_ycoor];

%Put together the x and y coor for the front segment, gap, and back segment
allPix = [snapsf; gap_coor; snapsb];

%Make storage for all the x and y coor of the final 204 downsampled points
%(subsequent analyses require 204 points evenly spaced over the total
%length of the foil)
SNAPSx = [];
SNAPSy = [];


colnum = 1;
incr=linspace(1,size(allPix,1),204);         %Will take 204 x values, which have these indices
incr=round(incr);       %Make sure indices are integers
spacing=0;      %initialize an index
k=0;            %initialize an index
while colnum<=size(incr,2)      %go through all the indices in incr
    spacing=spacing+1;
    k=incr(1,spacing);
    SNAPSx=[SNAPSx allPix(k,1)];          %add the x coor at point k of 204
    SNAPSy=[SNAPSy allPix(k,2)];        %add the y coor at point k of 204
    colnum=colnum+1;
end

%Add image number labels and format final result
SNAPSx = [im SNAPSx];
SNAPSy = [NaN SNAPSy];
SNAPS = [SNAPSx' SNAPSy'];




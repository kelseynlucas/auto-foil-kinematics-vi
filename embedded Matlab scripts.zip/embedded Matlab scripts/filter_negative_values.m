%This is a Matlab script embedded in the LabView auto foil kinematics vi.

%Filters out negative values (places where no foil was detected and an
%error sets the y-value to <0 instead of =0).  Output goes to 0
%filter/spline fitter.


%Inputs:
%X - the x-positions in the image in pixels
%Y - the y-values in the image where the foil is detected (or <=0 if no
    %foil detected)


%Output:
%A - an array with 2 rows.  Row 1 is the detected x data of the surface in pixels.
    %Row 2 contains the detected y data in pixels.


A=[X;Y];        %Combine x and y data into one matrix
totalcolumns=size(A,2);     %Get the number of data points

i=1;        %initialize an index
while i<=totalcolumns
    dataneg=(A(2,i)<0);    %Is the y-value negative?  Makes a boolean row vector with dimensions equal to the y data row of A.  0 if the value in A is >=0, 1 if the value in A is <0
    if dataneg==1
        A(2,i)=0;       %if a y-value in A is negative, change it to a 0 (will be filtered out later)
    end
    i=i+1;
end
%This is a Matlab script embedded in the LabView auto foil kinematics vi.

%Filters out zeros (places where no foil was detected) and fits a spline to
%the remaining points.  Simulates the rod WITH pitch.


%Inputs:
%A - an array with 2 rows.  Row 1 is the detected x data of the surface in mm.
    %Row 2 contains the detected y data in mm.
%rod - the rod width in mm
%pixfact - the DaVis pixel scale factor (mm/pixel conversion)
%im - the current image/frame number from the original video


%Output:
%SPL - the spline for the current frame of the foil video


totalcolumns=size(A,2);     %Get the number of data points
SPL=[];     %Initialize an array in which the spline will be stored

i=1;        %initialize an index
while i<=totalcolumns
    datanotzero=(A(2,i)~=0);    %make a boolean row vector with dimensions equal to the y data row of A.  0 if the value in A is 0, 1 if the value in A is not zero
    if datanotzero==0
        A(:,i)=0;   %if a y-value in A is 0, make its x-value zero too
    end
    i=i+1;
end

%Filter out the zeros; break into an x-data matrix and a y-data matrix
D1=A(1,:);
colnotzero=(D1~=0);
D1=D1(colnotzero);

D2=A(2,:);
colnotzero=(D2~=0);
D2=D2(colnotzero);


%Simulate rod - remove this section if rod is detected or not desired
n=50;       %number of points to use to make best fit line
fit=polyfit(D1(1,1:n),D2(1,1:n),1);     %make a best fit line for the first n detected points
r=fit(1).*D1(1,1:n)+fit(2);             %get the y-values on that best fit line
x1=D1(1,1);         %get the x of the detected leading edge of the foil
y1=r(1,1);          %get the y-value on the best fit line corresponding to x1
x=x1-sqrt((rod^2)/(1+(fit(1))^2));          %use distance formula (distance = rod width) following the line of best fit to calculate the x-value of the rod's leading edge is
y=y1-fit(1)*sqrt((rod^2)/(1+(fit(1))^2));       %use the distance formula as above to get the y-value of the rod's leading edge
xrod=[];        %initialize array to store rod x's
yrod=[];        %initialize array to store rod y's
xnew=0;         %initialize x value to be calculated
g=1;            %initialize index
while xnew+pixfact<x1           %keep adding points until reach the detected foil
    xnew=x+g*pixfact;           %get next x point on rod
    xrod=[xrod,xnew];           %store it
    yrod=[yrod,fit(1).*xnew+fit(2)];    %get and store the next y point on rod using the best fit line's formula
    g=g+1;
end
D1=[x,xrod,D1];         %add the rod onto the detected foil
D2=[y,yrod,D2];




%When fitting a spline to all the detected points, there's too many points
%to get a nice, smooth line.  Need to downsample the detected data.

colnum=1;       %initialize index (column number)
z=[];           %initialize array to store downsampled x's
zz=[];          %initialize array to store y's corresponding to the downsampled x's
incr=linspace(1,size(D1,2),20);         %Will take 20 x values, which have these indices
incr=round(incr);       %Make sure indices are integers
spacing=0;      %initialize an index
k=0;            %initialize an index
while colnum<=size(incr,2)      %go through all the indices in incr
    spacing=spacing+1;
    k=incr(1,spacing);
    z=[z D1(1,k)];          %take the x value at k, where k is the next index value listed in incr
    zz=[zz D2(1,k)];        %take the corresponding y value
    colnum=colnum+1;
end

p=linspace(z(1,1),z(1,end),204);        %Get 204 evenly spaced x values between the leading and trailing edges
q=spline(z,zz,p);                       %Fit a spline to the detected surface, and save it as a list of 204 points with x's as chosen in p
XSPLINE=[im p];         %label with image number
XSPLINE=XSPLINE';
YSPLINE=[NaN q];        %NaN to make y-value vector have same length as x-value vector
YSPLINE=YSPLINE';
SPL=[XSPLINE YSPLINE];      %store spline as two column array